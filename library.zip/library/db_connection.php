<?php
$server = "localhost";
$username = "root"; // replace with your MySQL username
$password = ""; // replace with your MySQL password
$database = "library_system";

// Create connection
$conn = mysqli_connect($server, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
