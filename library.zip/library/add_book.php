<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];

    $sql = "INSERT INTO books (title, author, genre) VALUES ('$title', '$author', '$genre')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
        header("Location: view_books.php"); // Redirect to view books page
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
