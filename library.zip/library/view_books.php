<?php
include 'db_connection.php';

$sql = "SELECT * FROM books";
$result = mysqli_query($conn, $sql);

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Library Management System</title>
    <link rel='stylesheet' href='styles.css'> <!-- Add your CSS link here -->
</head>
<body>";

echo "<header>
        <h1>Library Management System</h1>
        <nav>
            <ul>
                <li><a href='index.html'>Home</a></li>
                <li><a href='add_book.html'>Add Book</a></li>
                <li><a href='view_books.php'>View Books</a></li>
            </ul>
        </nav>
    </header>";

echo "<h1>Library Books</h1>";
echo "<table border='1'>";
echo "<tr><th>Title</th><th>Author</th><th>Genre</th><th>Status</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>" . $row['title'] . "</td><td>" . $row['author'] . "</td><td>" . $row['genre'] . "</td><td>" . $row['status'] . "</td></tr>";
}

echo "</table>";
echo" <!-- Footer Section -->
    <footer>
        <p>&copy; 2024 Library Management System. All rights reserved.</p>
    </footer>";

echo "</body></html>";

mysqli_close($conn);
?>
